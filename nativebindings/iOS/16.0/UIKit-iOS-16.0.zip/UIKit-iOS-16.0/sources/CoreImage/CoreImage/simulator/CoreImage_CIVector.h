#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIVector_symbols(JSContext*);
@protocol CIVectorInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly) size_t count;
@property (readonly) CGFloat X;
@property (readonly) CGFloat Y;
@property (readonly) CGFloat Z;
@property (readonly) CGFloat W;
@property (readonly) CGPoint CGPointValue;
@property (readonly) CGRect CGRectValue;
@property (readonly) CGAffineTransform CGAffineTransformValue;
@property (readonly) NSString * stringRepresentation;
JSExportAs(initWithX,
-(id) jsinitWithX: (CGFloat) x );
JSExportAs(initWithXY,
-(id) jsinitWithX: (CGFloat) x Y: (CGFloat) y );
JSExportAs(initWithXYZ,
-(id) jsinitWithX: (CGFloat) x Y: (CGFloat) y Z: (CGFloat) z );
JSExportAs(initWithXYZW,
-(id) jsinitWithX: (CGFloat) x Y: (CGFloat) y Z: (CGFloat) z W: (CGFloat) w );
JSExportAs(initWithCGPoint,
-(id) jsinitWithCGPoint: (CGPoint) p );
JSExportAs(initWithCGRect,
-(id) jsinitWithCGRect: (CGRect) r );
JSExportAs(initWithCGAffineTransform,
-(id) jsinitWithCGAffineTransform: (CGAffineTransform) r );
JSExportAs(initWithString,
-(id) jsinitWithString: (NSString *) representation );
-(CGFloat) valueAtIndex: (size_t) index ;
@end
@protocol CIVectorClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(id) vectorWithX: (CGFloat) x ;
+(id) vectorWithX: (CGFloat) x Y: (CGFloat) y ;
+(id) vectorWithX: (CGFloat) x Y: (CGFloat) y Z: (CGFloat) z ;
+(id) vectorWithX: (CGFloat) x Y: (CGFloat) y Z: (CGFloat) z W: (CGFloat) w ;
+(id) vectorWithCGPoint: (CGPoint) p ;
+(id) vectorWithCGRect: (CGRect) r ;
+(id) vectorWithCGAffineTransform: (CGAffineTransform) t ;
+(id) vectorWithString: (NSString *) representation ;
@end
#pragma clang diagnostic pop