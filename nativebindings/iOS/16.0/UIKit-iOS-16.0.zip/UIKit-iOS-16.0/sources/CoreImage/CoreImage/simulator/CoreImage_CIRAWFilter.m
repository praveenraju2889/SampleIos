#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
	class_addProtocol([CIRAWFilter class], @protocol(CIRAWFilterInstanceExports));
	class_addProtocol([CIRAWFilter class], @protocol(CIRAWFilterClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CIRAWDecoderVersionNone;
	if (p != NULL) context[@"CIRAWDecoderVersionNone"] = CIRAWDecoderVersionNone;
	p = (void*) &CIRAWDecoderVersion8;
	if (p != NULL) context[@"CIRAWDecoderVersion8"] = CIRAWDecoderVersion8;
	p = (void*) &CIRAWDecoderVersion8DNG;
	if (p != NULL) context[@"CIRAWDecoderVersion8DNG"] = CIRAWDecoderVersion8DNG;
	p = (void*) &CIRAWDecoderVersion7;
	if (p != NULL) context[@"CIRAWDecoderVersion7"] = CIRAWDecoderVersion7;
	p = (void*) &CIRAWDecoderVersion7DNG;
	if (p != NULL) context[@"CIRAWDecoderVersion7DNG"] = CIRAWDecoderVersion7DNG;
	p = (void*) &CIRAWDecoderVersion6;
	if (p != NULL) context[@"CIRAWDecoderVersion6"] = CIRAWDecoderVersion6;
	p = (void*) &CIRAWDecoderVersion6DNG;
	if (p != NULL) context[@"CIRAWDecoderVersion6DNG"] = CIRAWDecoderVersion6DNG;
}
void load_CoreImage_CIRAWFilter_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
