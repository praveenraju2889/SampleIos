#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIBarcodeDescriptor_symbols(JSContext*);
@protocol CIBarcodeDescriptorInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@end
@protocol CIBarcodeDescriptorClassExports<JSExport, NSSecureCodingClassExports_, NSCopyingClassExports_>
@end
@protocol CIQRCodeDescriptorInstanceExports<JSExport>
@property (readonly) NSData * errorCorrectedPayload;
@property (readonly) NSInteger symbolVersion;
@property (readonly) uint8_t maskPattern;
@property (readonly) CIQRCodeErrorCorrectionLevel errorCorrectionLevel;
JSExportAs(initWithPayloadSymbolVersionMaskPatternErrorCorrectionLevel,
-(id) jsinitWithPayload: (NSData *) errorCorrectedPayload symbolVersion: (NSInteger) symbolVersion maskPattern: (uint8_t) maskPattern errorCorrectionLevel: (CIQRCodeErrorCorrectionLevel) errorCorrectionLevel );
@end
@protocol CIQRCodeDescriptorClassExports<JSExport>
+(id) descriptorWithPayload: (NSData *) errorCorrectedPayload symbolVersion: (NSInteger) symbolVersion maskPattern: (uint8_t) maskPattern errorCorrectionLevel: (CIQRCodeErrorCorrectionLevel) errorCorrectionLevel ;
@end
@protocol CIAztecCodeDescriptorInstanceExports<JSExport>
@property (readonly) NSData * errorCorrectedPayload;
@property (readonly) BOOL isCompact;
@property (readonly) NSInteger layerCount;
@property (readonly) NSInteger dataCodewordCount;
JSExportAs(initWithPayloadIsCompactLayerCountDataCodewordCount,
-(id) jsinitWithPayload: (NSData *) errorCorrectedPayload isCompact: (BOOL) isCompact layerCount: (NSInteger) layerCount dataCodewordCount: (NSInteger) dataCodewordCount );
@end
@protocol CIAztecCodeDescriptorClassExports<JSExport>
+(id) descriptorWithPayload: (NSData *) errorCorrectedPayload isCompact: (BOOL) isCompact layerCount: (NSInteger) layerCount dataCodewordCount: (NSInteger) dataCodewordCount ;
@end
@protocol CIPDF417CodeDescriptorInstanceExports<JSExport>
@property (readonly) NSData * errorCorrectedPayload;
@property (readonly) BOOL isCompact;
@property (readonly) NSInteger rowCount;
@property (readonly) NSInteger columnCount;
JSExportAs(initWithPayloadIsCompactRowCountColumnCount,
-(id) jsinitWithPayload: (NSData *) errorCorrectedPayload isCompact: (BOOL) isCompact rowCount: (NSInteger) rowCount columnCount: (NSInteger) columnCount );
@end
@protocol CIPDF417CodeDescriptorClassExports<JSExport>
+(id) descriptorWithPayload: (NSData *) errorCorrectedPayload isCompact: (BOOL) isCompact rowCount: (NSInteger) rowCount columnCount: (NSInteger) columnCount ;
@end
@protocol CIDataMatrixCodeDescriptorInstanceExports<JSExport>
@property (readonly) NSData * errorCorrectedPayload;
@property (readonly) NSInteger rowCount;
@property (readonly) NSInteger columnCount;
@property (readonly) CIDataMatrixCodeECCVersion eccVersion;
JSExportAs(initWithPayloadRowCountColumnCountEccVersion,
-(id) jsinitWithPayload: (NSData *) errorCorrectedPayload rowCount: (NSInteger) rowCount columnCount: (NSInteger) columnCount eccVersion: (CIDataMatrixCodeECCVersion) eccVersion );
@end
@protocol CIDataMatrixCodeDescriptorClassExports<JSExport>
+(id) descriptorWithPayload: (NSData *) errorCorrectedPayload rowCount: (NSInteger) rowCount columnCount: (NSInteger) columnCount eccVersion: (CIDataMatrixCodeECCVersion) eccVersion ;
@end
@protocol NSUserActivityCIBarcodeDescriptorCategoryInstanceExports<JSExport>
@property (readonly,copy,nonatomic) CIBarcodeDescriptor * detectedBarcodeDescriptor;
@end
@protocol NSUserActivityCIBarcodeDescriptorCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop