#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIKernel_symbols(JSContext*);
@protocol CIKernelInstanceExports<JSExport>
@property (readonly,atomic) NSString * name;
JSExportAs(setROISelector,
-(void) jssetROISelector: (NSString *) method );
JSExportAs(applyWithExtentRoiCallbackArguments,
-(CIImage *) jsapplyWithExtent: (CGRect) extent roiCallback: (JSValue *) callback arguments: (NSArray *) args );
@end
@protocol CIKernelClassExports<JSExport>
+(NSArray *) kernelsWithString: (NSString *) string ;
JSExportAs(kernelsWithMetalStringError,
+(NSArray *) jskernelsWithMetalString: (NSString *) source error: (JSValue *) error );
+(id) kernelWithString: (NSString *) string ;
JSExportAs(kernelWithFunctionNameFromMetalLibraryDataError,
+(id) jskernelWithFunctionName: (NSString *) name fromMetalLibraryData: (NSData *) data error: (JSValue *) error );
JSExportAs(kernelWithFunctionNameFromMetalLibraryDataOutputPixelFormatError,
+(id) jskernelWithFunctionName: (NSString *) name fromMetalLibraryData: (NSData *) data outputPixelFormat: (CIFormat) format error: (JSValue *) error );
+(NSArray *) kernelNamesFromMetalLibraryData: (NSData *) data ;
@end
@protocol CIColorKernelInstanceExports<JSExport>
-(CIImage *) applyWithExtent: (CGRect) extent arguments: (NSArray *) args ;
@end
@protocol CIColorKernelClassExports<JSExport>
+(id) kernelWithString: (NSString *) string ;
@end
@protocol CIWarpKernelInstanceExports<JSExport>
JSExportAs(applyWithExtentRoiCallbackInputImageArguments,
-(CIImage *) jsapplyWithExtent: (CGRect) extent roiCallback: (JSValue *) callback inputImage: (CIImage *) image arguments: (NSArray *) args );
@end
@protocol CIWarpKernelClassExports<JSExport>
+(id) kernelWithString: (NSString *) string ;
@end
@protocol CIBlendKernelInstanceExports<JSExport>
-(CIImage *) applyWithForeground: (CIImage *) foreground background: (CIImage *) background ;
-(CIImage *) applyWithForeground: (CIImage *) foreground background: (CIImage *) background colorSpace: (id) colorSpace ;
@end
@protocol CIBlendKernelClassExports<JSExport>
+(id) kernelWithString: (NSString *) string ;
@end
@protocol CIBlendKernelBuiltInCategoryInstanceExports<JSExport>
@end
@protocol CIBlendKernelBuiltInCategoryClassExports<JSExport>
+(CIBlendKernel *) componentAdd;
+(CIBlendKernel *) componentMultiply;
+(CIBlendKernel *) componentMin;
+(CIBlendKernel *) componentMax;
+(CIBlendKernel *) clear;
+(CIBlendKernel *) source;
+(CIBlendKernel *) destination;
+(CIBlendKernel *) sourceOver;
+(CIBlendKernel *) destinationOver;
+(CIBlendKernel *) sourceIn;
+(CIBlendKernel *) destinationIn;
+(CIBlendKernel *) sourceOut;
+(CIBlendKernel *) destinationOut;
+(CIBlendKernel *) sourceAtop;
+(CIBlendKernel *) destinationAtop;
+(CIBlendKernel *) exclusiveOr;
+(CIBlendKernel *) multiply;
+(CIBlendKernel *) screen;
+(CIBlendKernel *) overlay;
+(CIBlendKernel *) darken;
+(CIBlendKernel *) lighten;
+(CIBlendKernel *) colorDodge;
+(CIBlendKernel *) colorBurn;
+(CIBlendKernel *) hardLight;
+(CIBlendKernel *) softLight;
+(CIBlendKernel *) difference;
+(CIBlendKernel *) exclusion;
+(CIBlendKernel *) hue;
+(CIBlendKernel *) saturation;
+(CIBlendKernel *) color;
+(CIBlendKernel *) luminosity;
+(CIBlendKernel *) subtract;
+(CIBlendKernel *) divide;
+(CIBlendKernel *) linearBurn;
+(CIBlendKernel *) linearDodge;
+(CIBlendKernel *) vividLight;
+(CIBlendKernel *) linearLight;
+(CIBlendKernel *) pinLight;
+(CIBlendKernel *) hardMix;
+(CIBlendKernel *) darkerColor;
+(CIBlendKernel *) lighterColor;
@end
#pragma clang diagnostic pop