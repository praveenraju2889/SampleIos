#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIContactsModules(JSContext* context);
JSValue* extractNFIContactsStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIContactsStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
