#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation CNLabeledValue (Exports)
-(id) jsinitWithLabel: (NSString *) label value: (id) value 
{
	id resultVal__;
	resultVal__ = [[self initWithLabel: label value: value ] autorelease];
	return resultVal__;
}
-(id) jsinitWithCoder: (NSCoder *) coder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: coder ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([CNLabeledValue class], @protocol(CNLabeledValueInstanceExports));
	class_addProtocol([CNLabeledValue class], @protocol(CNLabeledValueClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CNLabelURLAddressHomePage;
	if (p != NULL) context[@"CNLabelURLAddressHomePage"] = CNLabelURLAddressHomePage;
	p = (void*) &CNLabelWork;
	if (p != NULL) context[@"CNLabelWork"] = CNLabelWork;
	p = (void*) &CNLabelEmailiCloud;
	if (p != NULL) context[@"CNLabelEmailiCloud"] = CNLabelEmailiCloud;
	p = (void*) &CNLabelSchool;
	if (p != NULL) context[@"CNLabelSchool"] = CNLabelSchool;
	p = (void*) &CNLabelHome;
	if (p != NULL) context[@"CNLabelHome"] = CNLabelHome;
	p = (void*) &CNLabelOther;
	if (p != NULL) context[@"CNLabelOther"] = CNLabelOther;
	p = (void*) &CNLabelDateAnniversary;
	if (p != NULL) context[@"CNLabelDateAnniversary"] = CNLabelDateAnniversary;
}
void load_Contacts_CNLabeledValue_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
