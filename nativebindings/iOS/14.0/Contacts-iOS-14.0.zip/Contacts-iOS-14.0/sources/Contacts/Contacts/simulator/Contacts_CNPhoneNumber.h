#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNPhoneNumber_symbols(JSContext*);
@protocol CNPhoneNumberInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * stringValue;
JSExportAs(initWithStringValue,
-(id) jsinitWithStringValue: (NSString *) string );
-(id) jsinit;
@end
@protocol CNPhoneNumberClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(id) jsnew;
+(id) phoneNumberWithStringValue: (NSString *) stringValue ;
@end
#pragma clang diagnostic pop