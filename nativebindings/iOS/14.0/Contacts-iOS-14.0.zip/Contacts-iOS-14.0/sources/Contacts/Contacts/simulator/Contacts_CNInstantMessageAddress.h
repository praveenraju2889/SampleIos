#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNInstantMessageAddress_symbols(JSContext*);
@protocol CNInstantMessageAddressInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * username;
@property (readonly,copy,nonatomic) NSString * service;
JSExportAs(initWithUsernameService,
-(id) jsinitWithUsername: (NSString *) username service: (NSString *) service );
@end
@protocol CNInstantMessageAddressClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(NSString *) localizedStringForKey: (NSString *) key ;
+(NSString *) localizedStringForService: (NSString *) service ;
@end
#pragma clang diagnostic pop