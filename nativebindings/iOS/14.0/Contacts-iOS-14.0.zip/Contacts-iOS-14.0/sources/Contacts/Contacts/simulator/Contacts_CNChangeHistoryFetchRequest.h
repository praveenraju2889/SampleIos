#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNChangeHistoryFetchRequest_symbols(JSContext*);
@protocol CNChangeHistoryFetchRequestInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (copy,nonatomic) NSArray * excludedTransactionAuthors;
@property (nonatomic) BOOL shouldUnifyResults;
@property (nonatomic) BOOL includeGroupChanges;
@property (copy,nonatomic) NSData * startingToken;
@property (copy,nonatomic) NSArray * additionalContactKeyDescriptors;
@property (nonatomic) BOOL mutableObjects;
@end
@protocol CNChangeHistoryFetchRequestClassExports<JSExport, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop