#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation CNContactStore (Exports)
-(CNContact *) jsunifiedContactWithIdentifier: (NSString *) identifier keysToFetch: (NSArray *) keys error: (JSValue *) error 
{
	NSError* error_ = nil;
	CNContact * resultVal__;
	resultVal__ = [self unifiedContactWithIdentifier: identifier keysToFetch: keys error: &error_ ];
	if (error_ && [error isObject]) {
		error[@"error"] = error_;
	}
	return resultVal__;
}
-(NSArray *) jscontainersMatchingPredicate: (NSPredicate *) predicate error: (JSValue *) error 
{
	NSError* error_ = nil;
	NSArray * resultVal__;
	resultVal__ = [self containersMatchingPredicate: predicate error: &error_ ];
	if (error_ && [error isObject]) {
		error[@"error"] = error_;
	}
	return resultVal__;
}
-(NSArray *) jsgroupsMatchingPredicate: (NSPredicate *) predicate error: (JSValue *) error 
{
	NSError* error_ = nil;
	NSArray * resultVal__;
	resultVal__ = [self groupsMatchingPredicate: predicate error: &error_ ];
	if (error_ && [error isObject]) {
		error[@"error"] = error_;
	}
	return resultVal__;
}
-(BOOL) jsexecuteSaveRequest: (CNSaveRequest *) saveRequest error: (JSValue *) error 
{
	NSError* error_ = nil;
	BOOL resultVal__;
	resultVal__ = [self executeSaveRequest: saveRequest error: &error_ ];
	if (error_ && [error isObject]) {
		error[@"error"] = error_;
	}
	return resultVal__;
}
-(CNFetchResult *) jsenumeratorForContactFetchRequest: (CNContactFetchRequest *) request error: (JSValue *) error 
{
	NSError* error_ = nil;
	CNFetchResult * resultVal__;
	resultVal__ = [self enumeratorForContactFetchRequest: request error: &error_ ];
	if (error_ && [error isObject]) {
		error[@"error"] = error_;
	}
	return resultVal__;
}
-(CNFetchResult *) jsenumeratorForChangeHistoryFetchRequest: (CNChangeHistoryFetchRequest *) request error: (JSValue *) error 
{
	NSError* error_ = nil;
	CNFetchResult * resultVal__;
	resultVal__ = [self enumeratorForChangeHistoryFetchRequest: request error: &error_ ];
	if (error_ && [error isObject]) {
		error[@"error"] = error_;
	}
	return resultVal__;
}
-(void) jsrequestAccessForEntityType: (CNEntityType) entityType completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(BOOL, NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(BOOL arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self requestAccessForEntityType: entityType completionHandler: completionHandler_ ];
}
-(NSArray *) jsunifiedContactsMatchingPredicate: (NSPredicate *) predicate keysToFetch: (NSArray *) keys error: (JSValue *) error 
{
	NSError* error_ = nil;
	NSArray * resultVal__;
	resultVal__ = [self unifiedContactsMatchingPredicate: predicate keysToFetch: keys error: &error_ ];
	if (error_ && [error isObject]) {
		error[@"error"] = error_;
	}
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([CNContactStore class], @protocol(CNContactStoreInstanceExports));
	class_addProtocol([CNContactStore class], @protocol(CNContactStoreClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"CNEntityTypeContacts"] = @0L;

	context[@"CNAuthorizationStatusNotDetermined"] = @0L;
	context[@"CNAuthorizationStatusRestricted"] = @1L;
	context[@"CNAuthorizationStatusDenied"] = @2L;
	context[@"CNAuthorizationStatusAuthorized"] = @3L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CNContactStoreDidChangeNotification;
	if (p != NULL) context[@"CNContactStoreDidChangeNotification"] = CNContactStoreDidChangeNotification;
}
void load_Contacts_CNContactStore_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
