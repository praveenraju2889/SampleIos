#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNContact_Predicates_symbols(JSContext*);
@protocol CNContactPredicatesCategoryInstanceExports<JSExport>
@end
@protocol CNContactPredicatesCategoryClassExports<JSExport>
+(NSPredicate *) predicateForContactsMatchingEmailAddress: (NSString *) emailAddress ;
+(NSPredicate *) predicateForContactsMatchingName: (NSString *) name ;
+(NSPredicate *) predicateForContactsMatchingPhoneNumber: (CNPhoneNumber *) phoneNumber ;
+(NSPredicate *) predicateForContactsInGroupWithIdentifier: (NSString *) groupIdentifier ;
+(NSPredicate *) predicateForContactsWithIdentifiers: (NSArray *) identifiers ;
+(NSPredicate *) predicateForContactsInContainerWithIdentifier: (NSString *) containerIdentifier ;
@end
#pragma clang diagnostic pop