#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNPostalAddressFormatter_symbols(JSContext*);
@protocol CNPostalAddressFormatterInstanceExports<JSExport>
@property (nonatomic) CNPostalAddressFormatterStyle style;
-(NSString *) stringFromPostalAddress: (CNPostalAddress *) postalAddress ;
-(NSAttributedString *) attributedStringFromPostalAddress: (CNPostalAddress *) postalAddress withDefaultAttributes: (NSDictionary *) attributes ;
@end
@protocol CNPostalAddressFormatterClassExports<JSExport>
+(NSAttributedString *) attributedStringFromPostalAddress: (CNPostalAddress *) postalAddress style: (CNPostalAddressFormatterStyle) style withDefaultAttributes: (NSDictionary *) attributes ;
+(NSString *) stringFromPostalAddress: (CNPostalAddress *) postalAddress style: (CNPostalAddressFormatterStyle) style ;
@end
#pragma clang diagnostic pop