#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNMutableContact_symbols(JSContext*);
@protocol CNMutableContactInstanceExports<JSExport>
@property (copy,nonatomic) NSArray * socialProfiles;
@property (copy,nonatomic) NSArray * phoneNumbers;
@property (copy,nonatomic) NSData * imageData;
@property (copy,nonatomic) NSArray * instantMessageAddresses;
@property (nonatomic) CNContactType contactType;
@property (copy,nonatomic) NSString * phoneticMiddleName;
@property (copy,nonatomic) NSString * phoneticFamilyName;
@property (copy,nonatomic) NSString * middleName;
@property (copy,nonatomic) NSString * departmentName;
@property (copy,nonatomic) NSString * note;
@property (copy,nonatomic) NSArray * urlAddresses;
@property (copy,nonatomic) NSDateComponents * nonGregorianBirthday;
@property (copy,nonatomic) NSString * phoneticOrganizationName;
@property (copy,nonatomic) NSString * familyName;
@property (copy,nonatomic) NSString * jobTitle;
@property (copy,nonatomic) NSArray * contactRelations;
@property (copy,nonatomic) NSString * phoneticGivenName;
@property (copy,nonatomic) NSString * namePrefix;
@property (copy,nonatomic) NSString * nickname;
@property (copy,nonatomic) NSArray * dates;
@property (copy,nonatomic) NSString * organizationName;
@property (copy,nonatomic) NSString * nameSuffix;
@property (copy,nonatomic) NSDateComponents * birthday;
@property (copy,nonatomic) NSString * previousFamilyName;
@property (copy,nonatomic) NSArray * emailAddresses;
@property (copy,nonatomic) NSString * givenName;
@property (copy,nonatomic) NSArray * postalAddresses;
@end
@protocol CNMutableContactClassExports<JSExport>
@end
#pragma clang diagnostic pop