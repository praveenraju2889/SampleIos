#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNContactVCardSerialization_symbols(JSContext*);
@protocol CNContactVCardSerializationInstanceExports<JSExport>
@end
@protocol CNContactVCardSerializationClassExports<JSExport>
JSExportAs(contactsWithDataError,
+(NSArray *) jscontactsWithData: (NSData *) data error: (JSValue *) error );
JSExportAs(dataWithContactsError,
+(NSData *) jsdataWithContacts: (NSArray *) contacts error: (JSValue *) error );
+(id) descriptorForRequiredKeys;
@end
#pragma clang diagnostic pop