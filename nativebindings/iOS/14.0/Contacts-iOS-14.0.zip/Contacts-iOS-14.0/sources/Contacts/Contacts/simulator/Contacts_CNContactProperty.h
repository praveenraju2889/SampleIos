#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNContactProperty_symbols(JSContext*);
@protocol CNContactPropertyInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * identifier;
@property (readonly,copy,nonatomic) CNContact * contact;
@property (readonly,nonatomic) id value;
@property (readonly,copy,nonatomic) NSString * key;
@property (readonly,copy,nonatomic) NSString * label;
@end
@protocol CNContactPropertyClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop