#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation CNPhoneNumber (Exports)
-(id) jsinitWithStringValue: (NSString *) string 
{
	id resultVal__;
	resultVal__ = [[self initWithStringValue: string ] autorelease];
	return resultVal__;
}
-(id) jsinit
{
	id resultVal__;
	resultVal__ = [[self init] autorelease];
	return resultVal__;
}
-(id) jsinitWithCoder: (NSCoder *) coder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: coder ] autorelease];
	return resultVal__;
}
+(id) jsnew
{
	id resultVal__;
	resultVal__ = [[self new] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([CNPhoneNumber class], @protocol(CNPhoneNumberInstanceExports));
	class_addProtocol([CNPhoneNumber class], @protocol(CNPhoneNumberClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CNLabelPhoneNumberMobile;
	if (p != NULL) context[@"CNLabelPhoneNumberMobile"] = CNLabelPhoneNumberMobile;
	p = (void*) &CNLabelPhoneNumberWorkFax;
	if (p != NULL) context[@"CNLabelPhoneNumberWorkFax"] = CNLabelPhoneNumberWorkFax;
	p = (void*) &CNLabelPhoneNumberMain;
	if (p != NULL) context[@"CNLabelPhoneNumberMain"] = CNLabelPhoneNumberMain;
	p = (void*) &CNLabelPhoneNumberiPhone;
	if (p != NULL) context[@"CNLabelPhoneNumberiPhone"] = CNLabelPhoneNumberiPhone;
	p = (void*) &CNLabelPhoneNumberOtherFax;
	if (p != NULL) context[@"CNLabelPhoneNumberOtherFax"] = CNLabelPhoneNumberOtherFax;
	p = (void*) &CNLabelPhoneNumberPager;
	if (p != NULL) context[@"CNLabelPhoneNumberPager"] = CNLabelPhoneNumberPager;
	p = (void*) &CNLabelPhoneNumberHomeFax;
	if (p != NULL) context[@"CNLabelPhoneNumberHomeFax"] = CNLabelPhoneNumberHomeFax;
}
void load_Contacts_CNPhoneNumber_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
