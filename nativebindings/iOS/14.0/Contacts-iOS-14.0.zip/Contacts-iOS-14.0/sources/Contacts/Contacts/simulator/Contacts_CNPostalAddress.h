#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNPostalAddress_symbols(JSContext*);
@protocol CNPostalAddressInstanceExports<JSExport, NSCopyingInstanceExports_, NSMutableCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * city;
@property (readonly,copy,nonatomic) NSString * ISOCountryCode;
@property (readonly,copy,nonatomic) NSString * country;
@property (readonly,copy,nonatomic) NSString * state;
@property (readonly,copy,nonatomic) NSString * street;
@property (readonly,copy,nonatomic) NSString * subAdministrativeArea;
@property (readonly,copy,nonatomic) NSString * postalCode;
@property (readonly,copy,nonatomic) NSString * subLocality;
@end
@protocol CNPostalAddressClassExports<JSExport, NSCopyingClassExports_, NSMutableCopyingClassExports_, NSSecureCodingClassExports_>
+(NSString *) localizedStringForKey: (NSString *) key ;
@end
#pragma clang diagnostic pop