#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNSaveRequest_symbols(JSContext*);
@protocol CNSaveRequestInstanceExports<JSExport>
-(void) updateContact: (CNMutableContact *) contact ;
-(void) deleteGroup: (CNMutableGroup *) group ;
-(void) deleteContact: (CNMutableContact *) contact ;
-(void) addMember: (CNContact *) contact toGroup: (CNGroup *) group ;
-(void) addGroup: (CNMutableGroup *) group toContainerWithIdentifier: (NSString *) identifier ;
-(void) addContact: (CNMutableContact *) contact toContainerWithIdentifier: (NSString *) identifier ;
-(void) removeMember: (CNContact *) contact fromGroup: (CNGroup *) group ;
-(void) updateGroup: (CNMutableGroup *) group ;
@end
@protocol CNSaveRequestClassExports<JSExport>
@end
#pragma clang diagnostic pop