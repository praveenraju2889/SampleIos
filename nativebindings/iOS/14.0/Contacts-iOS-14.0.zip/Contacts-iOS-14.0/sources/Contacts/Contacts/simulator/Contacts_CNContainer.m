#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation CNContainer (Exports)
-(id) jsinitWithCoder: (NSCoder *) coder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: coder ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([CNContainer class], @protocol(CNContainerInstanceExports));
	class_addProtocol([CNContainer class], @protocol(CNContainerClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"CNContainerTypeUnassigned"] = @0L;
	context[@"CNContainerTypeLocal"] = @1L;
	context[@"CNContainerTypeExchange"] = @2L;
	context[@"CNContainerTypeCardDAV"] = @3L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CNContainerIdentifierKey;
	if (p != NULL) context[@"CNContainerIdentifierKey"] = CNContainerIdentifierKey;
	p = (void*) &CNContainerTypeKey;
	if (p != NULL) context[@"CNContainerTypeKey"] = CNContainerTypeKey;
	p = (void*) &CNContainerNameKey;
	if (p != NULL) context[@"CNContainerNameKey"] = CNContainerNameKey;
}
void load_Contacts_CNContainer_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
