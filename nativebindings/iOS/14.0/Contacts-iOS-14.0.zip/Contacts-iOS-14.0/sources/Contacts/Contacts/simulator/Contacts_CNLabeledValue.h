#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNLabeledValue_symbols(JSContext*);
@protocol CNLabeledValueInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * identifier;
@property (readonly,copy,nonatomic) id value;
@property (readonly,copy,nonatomic) NSString * label;
-(id) labeledValueBySettingLabel: (NSString *) label value: (id) value ;
JSExportAs(initWithLabelValue,
-(id) jsinitWithLabel: (NSString *) label value: (id) value );
-(id) labeledValueBySettingLabel: (NSString *) label ;
-(id) labeledValueBySettingValue: (id) value ;
@end
@protocol CNLabeledValueClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(NSString *) localizedStringForLabel: (NSString *) label ;
+(id) labeledValueWithLabel: (NSString *) label value: (id) value ;
@end
#pragma clang diagnostic pop