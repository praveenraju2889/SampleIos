#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNMutableGroup_symbols(JSContext*);
@protocol CNMutableGroupInstanceExports<JSExport>
@property (copy,nonatomic) NSString * name;
@end
@protocol CNMutableGroupClassExports<JSExport>
@end
#pragma clang diagnostic pop