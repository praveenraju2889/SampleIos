#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNSocialProfile_symbols(JSContext*);
@protocol CNSocialProfileInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * username;
@property (readonly,copy,nonatomic) NSString * service;
@property (readonly,copy,nonatomic) NSString * urlString;
@property (readonly,copy,nonatomic) NSString * userIdentifier;
JSExportAs(initWithUrlStringUsernameUserIdentifierService,
-(id) jsinitWithUrlString: (NSString *) urlString username: (NSString *) username userIdentifier: (NSString *) userIdentifier service: (NSString *) service );
@end
@protocol CNSocialProfileClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(NSString *) localizedStringForKey: (NSString *) key ;
+(NSString *) localizedStringForService: (NSString *) service ;
@end
#pragma clang diagnostic pop