#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFIContactsModules(JSContext* context)
{
	load_Contacts_CNContactProperty_symbols(context);
	load_Contacts_CNContainer_Predicates_symbols(context);
	load_Contacts_CNContactFormatter_symbols(context);
	load_Contacts_CNContactStore_symbols(context);
	load_Contacts_CNPostalAddressFormatter_symbols(context);
	load_Contacts_CNSocialProfile_symbols(context);
	load_Contacts_CNContactsUserDefaults_symbols(context);
	load_Contacts_CNMutablePostalAddress_symbols(context);
	load_Contacts_CNContactRelation_symbols(context);
	load_Contacts_CNContactFetchRequest_symbols(context);
	load_Contacts_CNChangeHistoryFetchRequest_symbols(context);
	load_Contacts_CNMutableContact_symbols(context);
	load_Contacts_CNContactVCardSerialization_symbols(context);
	load_Contacts_CNPostalAddress_symbols(context);
	load_Contacts_CNFetchResult_symbols(context);
	load_Contacts_CNContact_symbols(context);
	load_Contacts_CNMutableGroup_symbols(context);
	load_Contacts_CNContainer_symbols(context);
	load_Contacts_CNGroup_Predicates_symbols(context);
	load_Contacts_CNError_symbols(context);
	load_Contacts_CNInstantMessageAddress_symbols(context);
	load_Contacts_CNGroup_symbols(context);
	load_Contacts_CNPhoneNumber_symbols(context);
	load_Contacts_CNSaveRequest_symbols(context);
	load_Contacts_CNLabeledValue_symbols(context);
	load_Contacts_CNFetchRequest_symbols(context);
	load_Contacts_CNContact_NSItemProvider_symbols(context);
	load_Contacts_CNContact_Predicates_symbols(context);
	load_Contacts_CNChangeHistoryEvent_symbols(context);
}

JSValue* extractNFIContactsStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFIContactsStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}

