#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation NSString (NSStringContactsCategoryExports)
-(id) jsperformSelector: (NSString *) aSelector withObject: (id) object1 withObject: (id) object2 
{
	SEL aSelector_ = NSSelectorFromString(aSelector);
	id resultVal__;
	resultVal__ = [self performSelector: aSelector_ withObject: object1 withObject: object2 ];
	return resultVal__;
}
-(id) jsperformSelector: (NSString *) aSelector withObject: (id) object 
{
	SEL aSelector_ = NSSelectorFromString(aSelector);
	id resultVal__;
	resultVal__ = [self performSelector: aSelector_ withObject: object ];
	return resultVal__;
}
-(BOOL) jsrespondsToSelector: (NSString *) aSelector 
{
	SEL aSelector_ = NSSelectorFromString(aSelector);
	BOOL resultVal__;
	resultVal__ = [self respondsToSelector: aSelector_ ];
	return resultVal__;
}
-(BOOL) jsisKindOfClass: (JSValue *) aClass 
{
	Class aClass_ = objc_getClass([[aClass[@"className"] toString] cStringUsingEncoding: NSUTF8StringEncoding]);
	BOOL resultVal__;
	resultVal__ = [self isKindOfClass: aClass_ ];
	return resultVal__;
}
-(id) jsinitWithCoder: (NSCoder *) coder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: coder ] autorelease];
	return resultVal__;
}
-(id) jsperformSelector: (NSString *) aSelector 
{
	SEL aSelector_ = NSSelectorFromString(aSelector);
	id resultVal__;
	resultVal__ = [self performSelector: aSelector_ ];
	return resultVal__;
}
-(BOOL) jsisMemberOfClass: (JSValue *) aClass 
{
	Class aClass_ = objc_getClass([[aClass[@"className"] toString] cStringUsingEncoding: NSUTF8StringEncoding]);
	BOOL resultVal__;
	resultVal__ = [self isMemberOfClass: aClass_ ];
	return resultVal__;
}
-(JSValue *) getJsSuperclass
{
	return [JSValue valueWithObject: self.superclass inContext: [JSContext currentContext]];
}
@end
@implementation CNContact (Exports)
-(id) jsinitWithCoder: (NSCoder *) coder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: coder ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([NSString class], @protocol(NSStringContactsCategoryInstanceExports));
	class_addProtocol([NSString class], @protocol(NSStringContactsCategoryClassExports));
	class_addProtocol([CNContact class], @protocol(CNContactInstanceExports));
	class_addProtocol([CNContact class], @protocol(CNContactClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"CNContactTypePerson"] = @0L;
	context[@"CNContactTypeOrganization"] = @1L;

	context[@"CNContactSortOrderNone"] = @0L;
	context[@"CNContactSortOrderUserDefault"] = @1L;
	context[@"CNContactSortOrderGivenName"] = @2L;
	context[@"CNContactSortOrderFamilyName"] = @3L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CNContactIdentifierKey;
	if (p != NULL) context[@"CNContactIdentifierKey"] = CNContactIdentifierKey;
	p = (void*) &CNContactDepartmentNameKey;
	if (p != NULL) context[@"CNContactDepartmentNameKey"] = CNContactDepartmentNameKey;
	p = (void*) &CNContactImageDataKey;
	if (p != NULL) context[@"CNContactImageDataKey"] = CNContactImageDataKey;
	p = (void*) &CNContactInstantMessageAddressesKey;
	if (p != NULL) context[@"CNContactInstantMessageAddressesKey"] = CNContactInstantMessageAddressesKey;
	p = (void*) &CNContactUrlAddressesKey;
	if (p != NULL) context[@"CNContactUrlAddressesKey"] = CNContactUrlAddressesKey;
	p = (void*) &CNContactPhoneticFamilyNameKey;
	if (p != NULL) context[@"CNContactPhoneticFamilyNameKey"] = CNContactPhoneticFamilyNameKey;
	p = (void*) &CNContactGivenNameKey;
	if (p != NULL) context[@"CNContactGivenNameKey"] = CNContactGivenNameKey;
	p = (void*) &CNContactEmailAddressesKey;
	if (p != NULL) context[@"CNContactEmailAddressesKey"] = CNContactEmailAddressesKey;
	p = (void*) &CNContactRelationsKey;
	if (p != NULL) context[@"CNContactRelationsKey"] = CNContactRelationsKey;
	p = (void*) &CNContactImageDataAvailableKey;
	if (p != NULL) context[@"CNContactImageDataAvailableKey"] = CNContactImageDataAvailableKey;
	p = (void*) &CNContactPropertyNotFetchedExceptionName;
	if (p != NULL) context[@"CNContactPropertyNotFetchedExceptionName"] = CNContactPropertyNotFetchedExceptionName;
	p = (void*) &CNContactPostalAddressesKey;
	if (p != NULL) context[@"CNContactPostalAddressesKey"] = CNContactPostalAddressesKey;
	p = (void*) &CNContactTypeKey;
	if (p != NULL) context[@"CNContactTypeKey"] = CNContactTypeKey;
	p = (void*) &CNContactNamePrefixKey;
	if (p != NULL) context[@"CNContactNamePrefixKey"] = CNContactNamePrefixKey;
	p = (void*) &CNContactPreviousFamilyNameKey;
	if (p != NULL) context[@"CNContactPreviousFamilyNameKey"] = CNContactPreviousFamilyNameKey;
	p = (void*) &CNContactOrganizationNameKey;
	if (p != NULL) context[@"CNContactOrganizationNameKey"] = CNContactOrganizationNameKey;
	p = (void*) &CNContactDatesKey;
	if (p != NULL) context[@"CNContactDatesKey"] = CNContactDatesKey;
	p = (void*) &CNContactNameSuffixKey;
	if (p != NULL) context[@"CNContactNameSuffixKey"] = CNContactNameSuffixKey;
	p = (void*) &CNContactNonGregorianBirthdayKey;
	if (p != NULL) context[@"CNContactNonGregorianBirthdayKey"] = CNContactNonGregorianBirthdayKey;
	p = (void*) &CNContactPhoneticOrganizationNameKey;
	if (p != NULL) context[@"CNContactPhoneticOrganizationNameKey"] = CNContactPhoneticOrganizationNameKey;
	p = (void*) &CNContactThumbnailImageDataKey;
	if (p != NULL) context[@"CNContactThumbnailImageDataKey"] = CNContactThumbnailImageDataKey;
	p = (void*) &CNContactPhoneticGivenNameKey;
	if (p != NULL) context[@"CNContactPhoneticGivenNameKey"] = CNContactPhoneticGivenNameKey;
	p = (void*) &CNContactJobTitleKey;
	if (p != NULL) context[@"CNContactJobTitleKey"] = CNContactJobTitleKey;
	p = (void*) &CNContactPhoneticMiddleNameKey;
	if (p != NULL) context[@"CNContactPhoneticMiddleNameKey"] = CNContactPhoneticMiddleNameKey;
	p = (void*) &CNContactNicknameKey;
	if (p != NULL) context[@"CNContactNicknameKey"] = CNContactNicknameKey;
	p = (void*) &CNContactMiddleNameKey;
	if (p != NULL) context[@"CNContactMiddleNameKey"] = CNContactMiddleNameKey;
	p = (void*) &CNContactBirthdayKey;
	if (p != NULL) context[@"CNContactBirthdayKey"] = CNContactBirthdayKey;
	p = (void*) &CNContactPhoneNumbersKey;
	if (p != NULL) context[@"CNContactPhoneNumbersKey"] = CNContactPhoneNumbersKey;
	p = (void*) &CNContactNoteKey;
	if (p != NULL) context[@"CNContactNoteKey"] = CNContactNoteKey;
	p = (void*) &CNContactSocialProfilesKey;
	if (p != NULL) context[@"CNContactSocialProfilesKey"] = CNContactSocialProfilesKey;
	p = (void*) &CNContactFamilyNameKey;
	if (p != NULL) context[@"CNContactFamilyNameKey"] = CNContactFamilyNameKey;
}
void Contacts_CNContactProtocols()
{
	(void)@protocol(CNKeyDescriptor);
}
void load_Contacts_CNContact_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
