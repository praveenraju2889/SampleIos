#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNContactRelation_symbols(JSContext*);
@protocol CNContactRelationInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * name;
JSExportAs(initWithName,
-(id) jsinitWithName: (NSString *) name );
@end
@protocol CNContactRelationClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(id) contactRelationWithName: (NSString *) name ;
@end
#pragma clang diagnostic pop