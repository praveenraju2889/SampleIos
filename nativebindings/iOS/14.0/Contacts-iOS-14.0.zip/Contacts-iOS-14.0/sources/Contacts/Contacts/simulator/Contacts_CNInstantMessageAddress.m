#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation CNInstantMessageAddress (Exports)
-(id) jsinitWithUsername: (NSString *) username service: (NSString *) service 
{
	id resultVal__;
	resultVal__ = [[self initWithUsername: username service: service ] autorelease];
	return resultVal__;
}
-(id) jsinitWithCoder: (NSCoder *) coder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: coder ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([CNInstantMessageAddress class], @protocol(CNInstantMessageAddressInstanceExports));
	class_addProtocol([CNInstantMessageAddress class], @protocol(CNInstantMessageAddressClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CNInstantMessageAddressUsernameKey;
	if (p != NULL) context[@"CNInstantMessageAddressUsernameKey"] = CNInstantMessageAddressUsernameKey;
	p = (void*) &CNInstantMessageServiceJabber;
	if (p != NULL) context[@"CNInstantMessageServiceJabber"] = CNInstantMessageServiceJabber;
	p = (void*) &CNInstantMessageServiceSkype;
	if (p != NULL) context[@"CNInstantMessageServiceSkype"] = CNInstantMessageServiceSkype;
	p = (void*) &CNInstantMessageServiceGoogleTalk;
	if (p != NULL) context[@"CNInstantMessageServiceGoogleTalk"] = CNInstantMessageServiceGoogleTalk;
	p = (void*) &CNInstantMessageAddressServiceKey;
	if (p != NULL) context[@"CNInstantMessageAddressServiceKey"] = CNInstantMessageAddressServiceKey;
	p = (void*) &CNInstantMessageServiceQQ;
	if (p != NULL) context[@"CNInstantMessageServiceQQ"] = CNInstantMessageServiceQQ;
	p = (void*) &CNInstantMessageServiceFacebook;
	if (p != NULL) context[@"CNInstantMessageServiceFacebook"] = CNInstantMessageServiceFacebook;
	p = (void*) &CNInstantMessageServiceMSN;
	if (p != NULL) context[@"CNInstantMessageServiceMSN"] = CNInstantMessageServiceMSN;
	p = (void*) &CNInstantMessageServiceGaduGadu;
	if (p != NULL) context[@"CNInstantMessageServiceGaduGadu"] = CNInstantMessageServiceGaduGadu;
	p = (void*) &CNInstantMessageServiceYahoo;
	if (p != NULL) context[@"CNInstantMessageServiceYahoo"] = CNInstantMessageServiceYahoo;
	p = (void*) &CNInstantMessageServiceAIM;
	if (p != NULL) context[@"CNInstantMessageServiceAIM"] = CNInstantMessageServiceAIM;
	p = (void*) &CNInstantMessageServiceICQ;
	if (p != NULL) context[@"CNInstantMessageServiceICQ"] = CNInstantMessageServiceICQ;
}
void load_Contacts_CNInstantMessageAddress_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
