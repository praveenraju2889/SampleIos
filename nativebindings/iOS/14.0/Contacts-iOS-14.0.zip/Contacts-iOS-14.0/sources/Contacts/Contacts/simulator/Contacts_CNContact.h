#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNContact_symbols(JSContext*);
@protocol NSStringContactsCategoryInstanceExports<JSExport, CNKeyDescriptorInstanceExports_>
@end
@protocol NSStringContactsCategoryClassExports<JSExport, CNKeyDescriptorClassExports_>
@end
@protocol CNContactInstanceExports<JSExport, NSCopyingInstanceExports_, NSMutableCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSData * thumbnailImageData;
@property (readonly,copy,nonatomic) NSArray * phoneNumbers;
@property (readonly,copy,nonatomic) NSData * imageData;
@property (readonly,copy,nonatomic) NSArray * socialProfiles;
@property (readonly,copy,nonatomic) NSArray * instantMessageAddresses;
@property (readonly,nonatomic) BOOL imageDataAvailable;
@property (readonly,nonatomic) CNContactType contactType;
@property (readonly,copy,nonatomic) NSString * phoneticMiddleName;
@property (readonly,copy,nonatomic) NSString * phoneticFamilyName;
@property (readonly,copy,nonatomic) NSString * middleName;
@property (readonly,copy,nonatomic) NSString * departmentName;
@property (readonly,copy,nonatomic) NSString * note;
@property (readonly,copy,nonatomic) NSArray * urlAddresses;
@property (readonly,copy,nonatomic) NSDateComponents * nonGregorianBirthday;
@property (readonly,copy,nonatomic) NSString * phoneticOrganizationName;
@property (readonly,copy,nonatomic) NSArray * contactRelations;
@property (readonly,copy,nonatomic) NSString * jobTitle;
@property (readonly,copy,nonatomic) NSString * familyName;
@property (readonly,copy,nonatomic) NSString * phoneticGivenName;
@property (readonly,copy,nonatomic) NSString * namePrefix;
@property (readonly,copy,nonatomic) NSString * nickname;
@property (readonly,copy,nonatomic) NSArray * dates;
@property (readonly,copy,nonatomic) NSString * givenName;
@property (readonly,copy,nonatomic) NSString * organizationName;
@property (readonly,copy,nonatomic) NSString * nameSuffix;
@property (readonly,copy,nonatomic) NSDateComponents * birthday;
@property (readonly,copy,nonatomic) NSString * previousFamilyName;
@property (readonly,copy,nonatomic) NSArray * emailAddresses;
@property (readonly,copy,nonatomic) NSString * identifier;
@property (readonly,copy,nonatomic) NSArray * postalAddresses;
-(BOOL) isUnifiedWithContactWithIdentifier: (NSString *) contactIdentifier ;
-(BOOL) areKeysAvailable: (NSArray *) keyDescriptors ;
-(BOOL) isKeyAvailable: (NSString *) key ;
@end
@protocol CNContactClassExports<JSExport, NSCopyingClassExports_, NSMutableCopyingClassExports_, NSSecureCodingClassExports_>
+(NSString *) localizedStringForKey: (NSString *) key ;
+(id) descriptorForAllComparatorKeys;
+(NSComparator) comparatorForNameSortOrder: (CNContactSortOrder) sortOrder ;
@end
@protocol CNKeyDescriptorInstanceExports_<JSExport, NSObjectInstanceExports_, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@end
@protocol CNKeyDescriptorClassExports_<JSExport, NSObjectClassExports_, NSSecureCodingClassExports_, NSCopyingClassExports_>
@end
#pragma clang diagnostic pop