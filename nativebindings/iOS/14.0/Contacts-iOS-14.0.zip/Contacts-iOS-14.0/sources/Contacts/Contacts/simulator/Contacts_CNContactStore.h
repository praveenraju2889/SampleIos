#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNContactStore_symbols(JSContext*);
@protocol CNContactStoreInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSData * currentHistoryToken;
JSExportAs(unifiedContactWithIdentifierKeysToFetchError,
-(CNContact *) jsunifiedContactWithIdentifier: (NSString *) identifier keysToFetch: (NSArray *) keys error: (JSValue *) error );
JSExportAs(containersMatchingPredicateError,
-(NSArray *) jscontainersMatchingPredicate: (NSPredicate *) predicate error: (JSValue *) error );
-(NSString *) defaultContainerIdentifier;
JSExportAs(groupsMatchingPredicateError,
-(NSArray *) jsgroupsMatchingPredicate: (NSPredicate *) predicate error: (JSValue *) error );
JSExportAs(executeSaveRequestError,
-(BOOL) jsexecuteSaveRequest: (CNSaveRequest *) saveRequest error: (JSValue *) error );
JSExportAs(enumeratorForContactFetchRequestError,
-(CNFetchResult *) jsenumeratorForContactFetchRequest: (CNContactFetchRequest *) request error: (JSValue *) error );
JSExportAs(enumeratorForChangeHistoryFetchRequestError,
-(CNFetchResult *) jsenumeratorForChangeHistoryFetchRequest: (CNChangeHistoryFetchRequest *) request error: (JSValue *) error );
JSExportAs(requestAccessForEntityTypeCompletionHandler,
-(void) jsrequestAccessForEntityType: (CNEntityType) entityType completionHandler: (JSValue *) completionHandler );
JSExportAs(unifiedContactsMatchingPredicateKeysToFetchError,
-(NSArray *) jsunifiedContactsMatchingPredicate: (NSPredicate *) predicate keysToFetch: (NSArray *) keys error: (JSValue *) error );
@end
@protocol CNContactStoreClassExports<JSExport>
+(CNAuthorizationStatus) authorizationStatusForEntityType: (CNEntityType) entityType ;
@end
#pragma clang diagnostic pop