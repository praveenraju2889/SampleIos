#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNContactFormatter_symbols(JSContext*);
@protocol CNContactFormatterInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (nonatomic) CNContactFormatterStyle style;
-(NSAttributedString *) attributedStringFromContact: (CNContact *) contact defaultAttributes: (NSDictionary *) attributes ;
-(NSString *) stringFromContact: (CNContact *) contact ;
@end
@protocol CNContactFormatterClassExports<JSExport, NSSecureCodingClassExports_>
+(id) descriptorForRequiredKeysForNameOrder;
+(NSAttributedString *) attributedStringFromContact: (CNContact *) contact style: (CNContactFormatterStyle) style defaultAttributes: (NSDictionary *) attributes ;
+(NSString *) stringFromContact: (CNContact *) contact style: (CNContactFormatterStyle) style ;
+(id) descriptorForRequiredKeysForDelimiter;
+(CNContactDisplayNameOrder) nameOrderForContact: (CNContact *) contact ;
+(NSString *) delimiterForContact: (CNContact *) contact ;
+(id) descriptorForRequiredKeysForStyle: (CNContactFormatterStyle) style ;
@end
#pragma clang diagnostic pop