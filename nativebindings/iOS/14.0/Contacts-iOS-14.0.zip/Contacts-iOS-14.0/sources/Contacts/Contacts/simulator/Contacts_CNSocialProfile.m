#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation CNSocialProfile (Exports)
-(id) jsinitWithUrlString: (NSString *) urlString username: (NSString *) username userIdentifier: (NSString *) userIdentifier service: (NSString *) service 
{
	id resultVal__;
	resultVal__ = [[self initWithUrlString: urlString username: username userIdentifier: userIdentifier service: service ] autorelease];
	return resultVal__;
}
-(id) jsinitWithCoder: (NSCoder *) coder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: coder ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([CNSocialProfile class], @protocol(CNSocialProfileInstanceExports));
	class_addProtocol([CNSocialProfile class], @protocol(CNSocialProfileClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CNSocialProfileServiceTwitter;
	if (p != NULL) context[@"CNSocialProfileServiceTwitter"] = CNSocialProfileServiceTwitter;
	p = (void*) &CNSocialProfileUserIdentifierKey;
	if (p != NULL) context[@"CNSocialProfileUserIdentifierKey"] = CNSocialProfileUserIdentifierKey;
	p = (void*) &CNSocialProfileServiceFlickr;
	if (p != NULL) context[@"CNSocialProfileServiceFlickr"] = CNSocialProfileServiceFlickr;
	p = (void*) &CNSocialProfileServiceGameCenter;
	if (p != NULL) context[@"CNSocialProfileServiceGameCenter"] = CNSocialProfileServiceGameCenter;
	p = (void*) &CNSocialProfileURLStringKey;
	if (p != NULL) context[@"CNSocialProfileURLStringKey"] = CNSocialProfileURLStringKey;
	p = (void*) &CNSocialProfileServiceFacebook;
	if (p != NULL) context[@"CNSocialProfileServiceFacebook"] = CNSocialProfileServiceFacebook;
	p = (void*) &CNSocialProfileServiceYelp;
	if (p != NULL) context[@"CNSocialProfileServiceYelp"] = CNSocialProfileServiceYelp;
	p = (void*) &CNSocialProfileServiceSinaWeibo;
	if (p != NULL) context[@"CNSocialProfileServiceSinaWeibo"] = CNSocialProfileServiceSinaWeibo;
	p = (void*) &CNSocialProfileServiceTencentWeibo;
	if (p != NULL) context[@"CNSocialProfileServiceTencentWeibo"] = CNSocialProfileServiceTencentWeibo;
	p = (void*) &CNSocialProfileServiceKey;
	if (p != NULL) context[@"CNSocialProfileServiceKey"] = CNSocialProfileServiceKey;
	p = (void*) &CNSocialProfileServiceLinkedIn;
	if (p != NULL) context[@"CNSocialProfileServiceLinkedIn"] = CNSocialProfileServiceLinkedIn;
	p = (void*) &CNSocialProfileUsernameKey;
	if (p != NULL) context[@"CNSocialProfileUsernameKey"] = CNSocialProfileUsernameKey;
	p = (void*) &CNSocialProfileServiceMySpace;
	if (p != NULL) context[@"CNSocialProfileServiceMySpace"] = CNSocialProfileServiceMySpace;
}
void load_Contacts_CNSocialProfile_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
