#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNFetchResult_symbols(JSContext*);
@protocol CNFetchResultInstanceExports<JSExport>
@property (readonly,nonatomic,strong) id value;
@property (readonly,copy,nonatomic) NSData * currentHistoryToken;
@end
@protocol CNFetchResultClassExports<JSExport>
@end
#pragma clang diagnostic pop