#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"CNErrorCodeCommunicationError"] = @1L;
	context[@"CNErrorCodeDataAccessError"] = @2L;
	context[@"CNErrorCodeAuthorizationDenied"] = @100L;
	context[@"CNErrorCodeNoAccessableWritableContainers"] = @101L;
	context[@"CNErrorCodeUnauthorizedKeys"] = @102L;
	context[@"CNErrorCodeFeatureDisabledByUser"] = @103L;
	context[@"CNErrorCodeRecordDoesNotExist"] = @200L;
	context[@"CNErrorCodeInsertedRecordAlreadyExists"] = @201L;
	context[@"CNErrorCodeContainmentCycle"] = @202L;
	context[@"CNErrorCodeContainmentScope"] = @203L;
	context[@"CNErrorCodeParentRecordDoesNotExist"] = @204L;
	context[@"CNErrorCodeRecordIdentifierInvalid"] = @205L;
	context[@"CNErrorCodeRecordNotWritable"] = @206L;
	context[@"CNErrorCodeParentContainerNotWritable"] = @207L;
	context[@"CNErrorCodeValidationMultipleErrors"] = @300L;
	context[@"CNErrorCodeValidationTypeMismatch"] = @301L;
	context[@"CNErrorCodeValidationConfigurationError"] = @302L;
	context[@"CNErrorCodePredicateInvalid"] = @400L;
	context[@"CNErrorCodePolicyViolation"] = @500L;
	context[@"CNErrorCodeClientIdentifierInvalid"] = @600L;
	context[@"CNErrorCodeClientIdentifierDoesNotExist"] = @601L;
	context[@"CNErrorCodeClientIdentifierCollision"] = @602L;
	context[@"CNErrorCodeChangeHistoryExpired"] = @603L;
	context[@"CNErrorCodeChangeHistoryInvalidAnchor"] = @604L;
	context[@"CNErrorCodeVCardMalformed"] = @700L;
	context[@"CNErrorCodeVCardSummarizationError"] = @701L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CNErrorUserInfoAffectedRecordsKey;
	if (p != NULL) context[@"CNErrorUserInfoAffectedRecordsKey"] = CNErrorUserInfoAffectedRecordsKey;
	p = (void*) &CNErrorUserInfoValidationErrorsKey;
	if (p != NULL) context[@"CNErrorUserInfoValidationErrorsKey"] = CNErrorUserInfoValidationErrorsKey;
	p = (void*) &CNErrorUserInfoAffectedRecordIdentifiersKey;
	if (p != NULL) context[@"CNErrorUserInfoAffectedRecordIdentifiersKey"] = CNErrorUserInfoAffectedRecordIdentifiersKey;
	p = (void*) &CNErrorDomain;
	if (p != NULL) context[@"CNErrorDomain"] = CNErrorDomain;
	p = (void*) &CNErrorUserInfoKeyPathsKey;
	if (p != NULL) context[@"CNErrorUserInfoKeyPathsKey"] = CNErrorUserInfoKeyPathsKey;
}
void load_Contacts_CNError_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
