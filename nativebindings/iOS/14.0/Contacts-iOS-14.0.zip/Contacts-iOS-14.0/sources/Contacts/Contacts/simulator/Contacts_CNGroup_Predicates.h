#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNGroup_Predicates_symbols(JSContext*);
@protocol CNGroupPredicatesCategoryInstanceExports<JSExport>
@end
@protocol CNGroupPredicatesCategoryClassExports<JSExport>
+(NSPredicate *) predicateForGroupsWithIdentifiers: (NSArray *) identifiers ;
+(NSPredicate *) predicateForGroupsInContainerWithIdentifier: (NSString *) containerIdentifier ;
@end
#pragma clang diagnostic pop