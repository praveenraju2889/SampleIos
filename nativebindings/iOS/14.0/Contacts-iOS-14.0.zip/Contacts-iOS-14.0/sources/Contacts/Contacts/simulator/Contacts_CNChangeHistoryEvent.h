#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Contacts_CNChangeHistoryEvent_symbols(JSContext*);
@protocol CNChangeHistoryAddMemberToGroupEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) CNContact * member;
@property (readonly,nonatomic,strong) CNGroup * group;
@end
@protocol CNChangeHistoryAddMemberToGroupEventClassExports<JSExport>
@end
@protocol CNChangeHistoryDeleteGroupEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) NSString * groupIdentifier;
@end
@protocol CNChangeHistoryDeleteGroupEventClassExports<JSExport>
@end
@protocol CNChangeHistoryUpdateGroupEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) CNGroup * group;
@end
@protocol CNChangeHistoryUpdateGroupEventClassExports<JSExport>
@end
@protocol CNChangeHistoryUpdateContactEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) CNContact * contact;
@end
@protocol CNChangeHistoryUpdateContactEventClassExports<JSExport>
@end
@protocol CNChangeHistoryAddGroupEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) CNGroup * group;
@property (readonly,nonatomic,strong) NSString * containerIdentifier;
@end
@protocol CNChangeHistoryAddGroupEventClassExports<JSExport>
@end
@protocol CNChangeHistoryAddContactEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) CNContact * contact;
@property (readonly,nonatomic,strong) NSString * containerIdentifier;
@end
@protocol CNChangeHistoryAddContactEventClassExports<JSExport>
@end
@protocol CNChangeHistoryRemoveSubgroupFromGroupEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) CNGroup * group;
@property (readonly,nonatomic,strong) CNGroup * subgroup;
@end
@protocol CNChangeHistoryRemoveSubgroupFromGroupEventClassExports<JSExport>
@end
@protocol CNChangeHistoryAddSubgroupToGroupEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) CNGroup * group;
@property (readonly,nonatomic,strong) CNGroup * subgroup;
@end
@protocol CNChangeHistoryAddSubgroupToGroupEventClassExports<JSExport>
@end
@protocol CNChangeHistoryEventInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
-(void) acceptEventVisitor: (id) visitor ;
@end
@protocol CNChangeHistoryEventClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
@protocol CNChangeHistoryDeleteContactEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) NSString * contactIdentifier;
@end
@protocol CNChangeHistoryDeleteContactEventClassExports<JSExport>
@end
@protocol CNChangeHistoryDropEverythingEventInstanceExports<JSExport>
@end
@protocol CNChangeHistoryDropEverythingEventClassExports<JSExport>
@end
@protocol CNChangeHistoryRemoveMemberFromGroupEventInstanceExports<JSExport>
@property (readonly,nonatomic,strong) CNContact * member;
@property (readonly,nonatomic,strong) CNGroup * group;
@end
@protocol CNChangeHistoryRemoveMemberFromGroupEventClassExports<JSExport>
@end
@protocol CNChangeHistoryEventVisitorInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) visitAddSubgroupToGroupEvent: (CNChangeHistoryAddSubgroupToGroupEvent *) event ;
-(void) visitAddMemberToGroupEvent: (CNChangeHistoryAddMemberToGroupEvent *) event ;
-(void) visitAddGroupEvent: (CNChangeHistoryAddGroupEvent *) event ;
-(void) visitAddContactEvent: (CNChangeHistoryAddContactEvent *) event ;
-(void) visitRemoveSubgroupFromGroupEvent: (CNChangeHistoryRemoveSubgroupFromGroupEvent *) event ;
-(void) visitUpdateContactEvent: (CNChangeHistoryUpdateContactEvent *) event ;
-(void) visitRemoveMemberFromGroupEvent: (CNChangeHistoryRemoveMemberFromGroupEvent *) event ;
-(void) visitDeleteGroupEvent: (CNChangeHistoryDeleteGroupEvent *) event ;
-(void) visitDropEverythingEvent: (CNChangeHistoryDropEverythingEvent *) event ;
-(void) visitUpdateGroupEvent: (CNChangeHistoryUpdateGroupEvent *) event ;
-(void) visitDeleteContactEvent: (CNChangeHistoryDeleteContactEvent *) event ;
@end
@protocol CNChangeHistoryEventVisitorClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop